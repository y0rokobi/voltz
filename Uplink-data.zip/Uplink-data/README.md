# Uplink Data

This branch is where all official display data is stored. In the future, servers will be able to send a new url for client mods to use.

**Note:** All files must be named as specified: `<client id>.json`
